# Jadoomantar

A Python package for creating an invisible cloak effect using OpenCV. 

### for a special friend

## Installation

```bash
pip install jadoomantar
